import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

import '../models/Service_Modele.dart';

class ServiceController {
   Database? _database;

  Future<void> open() async {
    if (_database == null) {
      _database = await openDatabase(
        join(await getDatabasesPath(), 'test11.db'),
        onCreate: (db, version) {
          return db.execute(
            "CREATE TABLE services(id INTEGER PRIMARY KEY AUTOINCREMENT, nom_ets TEXT, sigle TEXT, adresse TEXT, form_jurid TEXT, tel TEXT, contact TEXT, email TEXT, rccm TEXT, datercm TEXT, ville TEXT, activite TEXT, capital TEXT, effectif TEXT, nationaux TEXT, cadres TEXT, employeur TEXT, datecre TEXT, site TEXT, femme TEXT, libellec TEXT, activite_id TEXT, geoloc TEXT, montant_negoc_soc TEXT)",
          );
        },
        version: 1,
      );
    }
  }

  Future<void> close() async {
    await _database!.close();
  }

  Future<int> insert(ServiceModel service) async {
    await open();
    int id = await _database!.insert('services', service.toMap());
    await close();
    return id;
  }

  Future<List<ServiceModel>> getAll() async {
    await open();
    final List<Map<String, dynamic>> maps = await _database!.query('services');
    await close();
    return List.generate(maps.length, (i) {
      return ServiceModel.fromMap(maps[i]);
    });
  }

  Future<ServiceModel> getById(int id) async {
    await open();
    List<Map<String, dynamic>> maps =
        await _database!.query('services', where: 'id = ?', whereArgs: [id]);
    await close();
    if (maps.isNotEmpty) {
      return ServiceModel.fromMap(maps.first);
    } else {
      throw Exception('Service with id $id not found');
    }
  }

  Future<int> update(ServiceModel service) async {
    await open();
    int rowsAffected = await _database!.update('services', service.toMap(),
        where: 'id = ?', whereArgs: [service.id]);
    await close();
    return rowsAffected;
  }

  Future<int> delete(int id) async {
    await open();
    int rowsAffected =
        await _database!.delete('services', where: 'id = ?', whereArgs: [id]);
    await close();
    return rowsAffected;
  }
}
