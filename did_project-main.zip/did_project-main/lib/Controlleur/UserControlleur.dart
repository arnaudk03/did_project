import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

import '../models/Service_Modele.dart';
import '../models/user_Model.dart';

class UserController {
  Database? _database;

  Future<void> open() async {
    if (_database == null) {
      _database = await openDatabase(
        join(await getDatabasesPath(), 'test11.db'),
        onCreate: (db, version) {
          return db.execute(
            "CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT, password TEXT)",
          );
        },
        version: 1,
      );
    }
  }

  Future<void> close() async {
    await _database!.close();
  }

  Future<int> insert(UserModel users) async {
    await open();
    int id = await _database!.insert('users', users.toMap());
    await close();
    return id;
  }

  Future<UserModel> getById(int id) async {
    await open();
    List<Map<String, dynamic>> maps =
        await _database!.query('users', where: 'id = ?', whereArgs: [id]);
    await close();
    if (maps.isNotEmpty) {
      return UserModel.fromMap(maps.first);
    } else {
      throw Exception('User with id $id not found');
    }
  }

  Future<int> update(UserModel users) async {
    await open();
    int rowsAffected = await _database!
        .update('users', users.toMap(), where: 'id = ?', whereArgs: [users.id]);
    await close();
    return rowsAffected;
  }

  Future<int> delete(int id) async {
    await open();
    int rowsAffected =
        await _database!.delete('users', where: 'id = ?', whereArgs: [id]);
    await close();
    return rowsAffected;
  }

  Future<bool> auth(String email, String password) async {
    await open();
    final result = await _database!.query('users',
        where: 'email = ? AND password = ?', whereArgs: [email, password]);
    await close();
    return result.isNotEmpty;
  }
}
