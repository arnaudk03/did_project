class ServiceModel {
  late int id;
  late String nom_ets;
  late String sigle;
  late String adresse;
  late String form_jurid;
  late String tel;
  late String contact;
  late String email;
  late String rccm;
  late String datercm;
  late String ville;
  late String activite;
  late String capital;
  late String effectif;
  late String nationaux;
  late String cadres;
  late String employeur;
  late String datecre;
  late String site;
  late String femme;
  late String libellec;
  late String activite_id;
  late String geoloc;
  late String montant_negoc_soc;

  ServiceModel({
    this.id = 0,
    this.nom_ets = "",
    this.sigle = "",
    this.adresse = "",
    this.form_jurid = "",
    this.tel = "",
    this.contact = "",
    this.email = "",
    this.rccm = "",
    this.datercm = "",
    this.ville = "",
    this.activite = "",
    this.capital = "",
    this.effectif = "",
    this.nationaux = "",
    this.cadres = "",
    this.employeur = "",
    this.datecre = "",
    this.site = "",
    this.femme = "",
    this.libellec = "",
    this.activite_id = "",
    this.geoloc = "",
    this.montant_negoc_soc = "",
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nom_ets': nom_ets,
      'sigle': sigle,
      'adresse': adresse,
      'form_jurid': form_jurid,
      'tel': tel,
      'contact': contact,
      'email': email,
      'rccm': rccm,
      'datercm': datercm,
      'ville': ville,
      'activite': activite,
      'capital': capital,
      'effectif': effectif,
      'nationaux': nationaux,
      'cadres': cadres,
      'employeur': employeur,
      'datecre': datecre,
      'site': site,
      'femme': femme,
      'libellec': libellec,
      'activite_id': activite_id,
      'geoloc': geoloc,
      'montant_negoc_soc': montant_negoc_soc,
    };
  }

  factory ServiceModel.fromMap(Map<String, dynamic> map) {
    return ServiceModel(
        id: map['id'],
        nom_ets: map['nom_ets'],
        sigle: map['sigle'],
        adresse: map['adresse'],
        form_jurid: map['form_jurid'],
        tel: map['tel'],
        contact: map['contact'],
        email: map['email'],
        rccm: map['rccm'],
        datercm: map['datercm'],
        ville: map['ville'],
        activite: map['activite'],
        capital: map['capital'],
        effectif: map['effectif'],
        nationaux: map['nationaux'],
        cadres: map['cadres'],
        employeur: map['employeur'],
        datecre: map['datecre'],
        site: map['site'],
        femme: map['femme'],
        libellec: map['libellec'],
        activite_id: map['activite_id'],
        geoloc: map['geoloc'],
        montant_negoc_soc: map['montant_negoc_soc']);
  }
}
