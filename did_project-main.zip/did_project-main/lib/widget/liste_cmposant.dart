import 'package:flutter/material.dart';

import '../consts/global_colors.dart';

class Liste_composant extends StatefulWidget {
  String name;
  String contenu;

  Liste_composant({
    required this.name,
    required this.contenu,
  });
  @override
  _Liste_composantState createState() => _Liste_composantState();
}

class _Liste_composantState extends State<Liste_composant> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(left: 0, right: 0, top: 0, bottom: 0),
      child: Card(
        color: Colors.grey.shade600,
        margin: const EdgeInsets.fromLTRB(0, 0, 0, 0),
        elevation: 3,
        child: ListTile(
            focusColor: Colors.white,
            title: Text(
              widget.contenu,
              style: TextStyle(color: lightIconsColor),
            ),
            tileColor: Colors.white,
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                    icon: const Icon(
                      Icons.remove_red_eye,
                      color: Colors.green,
                    ),
                    onPressed: () => {}),
                // Edit button

                IconButton(
                  icon: const Icon(
                    Icons.location_on,
                    color: Colors.red,
                  ),
                  onPressed: () => {},
                ),
              ],
            )),
      ),
    );
  }
}
