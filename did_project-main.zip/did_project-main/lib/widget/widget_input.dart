import 'package:flutter/material.dart';

import '../consts/global_colors.dart';

class Widget_input extends StatelessWidget {
  final String placeholder;
  TextEditingController control = new TextEditingController();

  Widget_input({super.key, required this.placeholder, required this.control});

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: control,
      decoration: InputDecoration(
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(width: 3, color: lightIconsColor)),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(width: 3, color: Colors.red),
        ),
        labelText: "Nom d'utilisateur ou Email",
        labelStyle: TextStyle(color: Colors.black, fontFamily: "HK Grotesk"),
      ),
      onChanged: (value) {},
    );
  }
}
