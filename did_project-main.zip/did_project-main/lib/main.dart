import 'package:flutter/material.dart';
import 'package:recouvre_mobile/consts/global_colors.dart';
import 'package:recouvre_mobile/screens/login_page/user_screen.dart';

import 'Controlleur/ServiceControlleur.dart';
import 'Controlleur/UserControlleur.dart';
import 'models/Service_Modele.dart';
import 'models/user_Model.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  UserModel user =
      UserModel(id: 0, email: "email@gmail.com", password: "password");
  UserController userdb = UserController();
  ServiceController memoDb = ServiceController();
  ServiceModel service = ServiceModel(
      id: 4,
      nom_ets: "Mon entreprise",
      sigle: "ME",
      adresse: "123 rue du Commerce",
      form_jurid: "SARL",
      tel: "0123456789",
      contact: "John Doe",
      email: "contact@monentreprise.com",
      rccm: "012345",
      datercm: "01/01/2021",
      ville: "Paris",
      activite: "Informatique",
      capital: "10000",
      effectif: "10",
      nationaux: "5",
      cadres: "3",
      employeur: "true",
      datecre: "01/01/2020",
      site: "www.monentreprise.com",
      femme: "false",
      libellec: "0123456",
      activite_id: "1",
      geoloc: "48.856614, 2.3522219",
      montant_negoc_soc: "20000");
  //userdb.insert(user);

  //memoDb.insert(service);
  // print(await memoDb.getAll());

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'APP',
      home: Connexion(),
    );
  }
}
