import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http/http.dart' as http;
import 'package:recouvre_mobile/Controlleur/ServiceControlleur.dart';
import 'dart:convert';

import 'package:recouvre_mobile/consts/global_colors.dart';
import 'package:recouvre_mobile/screens/navigator.dart';

import '../../Controlleur/UserControlleur.dart';
import '../../widget/widget_input.dart';

class Connexion extends StatefulWidget {
  Connexion({Key? key}) : super(key: key);
  @override
  _Connexion createState() => _Connexion();
}

class _Connexion extends State<Connexion> {
  @override
  void initState() {}

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Contenu(),
      ),
    );
  }
}

class Contenu extends StatefulWidget {
  @override
  _Contenu createState() => _Contenu();
}

class _Contenu extends State<Contenu> {
  var _obscureText = true;
  @override
  Widget build(BuildContext context) {
    var mediaQueryData = MediaQuery.of(context);
    final width = mediaQueryData.size.width;
    final height = mediaQueryData.size.height;
    TextEditingController email = new TextEditingController();
    TextEditingController password = new TextEditingController();

    return Column(children: [
      SizedBox(
        height: height / 10,
      ),
      Row(
        children: [
          SizedBox(
            width: width / 4,
          ),
          Center(
            child: SizedBox(
              child: Image.asset(
                "assets/images/login.png",
                height: 200,
                width: width / 2,
              ),
            ),
          ),
        ],
      ),
      SizedBox(
        height: 20,
      ),
      Row(
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(20, 0, 0, 0),
            child: Text(
              "Connexion",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 48,
                  fontFamily: "HK Grotesk"),
            ),
          ),
        ],
      ),
      Row(
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(20, 10, 0, 0),
            child: Text(
              "Heureux de vous revoir",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  fontFamily: "HK Grotesk"),
            ),
          ),
        ],
      ),
      Row(
        children: [
          Form(
              child: Column(
            children: [
              Row(
                children: [
                  Container(
                      height: height / 9,
                      width: width,
                      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                      child: Widget_input(
                        placeholder: "Nom d'utilisateur ou Email",
                        control: email,
                      )),
                ],
              ),
              Row(
                children: [
                  Container(
                    height: height / 9,
                    width: width,
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                    child: TextField(
                      obscureText: _obscureText,
                      controller: password,
                      decoration: InputDecoration(
                        suffixIcon: IconButton(
                          icon: Icon(Icons.visibility_off_outlined),
                          onPressed: () {
                            setState(() {
                              _obscureText = !_obscureText;
                            });
                          },
                        ),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(width: 3, color: lightIconsColor)),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(width: 3, color: Colors.red),
                        ),
                        labelText: "Mot de passe",
                        labelStyle: TextStyle(
                            color: Colors.black, fontFamily: "HK Grotesk"),
                      ),
                      onChanged: (value) {},
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Center(
                    child: Text(
                      "Mot de passe oublié",
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 20,
              ),
              Container(
                padding: EdgeInsets.fromLTRB(width / 20, 0, width / 20, 0),
                height: (height / 17),
                width: width,
                child: OutlinedButton(
                  onPressed: () async {
                    UserController userdb = UserController();
                    if (await userdb.auth(email.text, password.text)) {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (_) => Navigateur()));
                    }
                  },
                  child: Row(
                    children: [
                      Column(
                        // mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: 15,
                          ),
                          Align(
                              alignment: Alignment.topCenter,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(
                                    width / 4, 0, width / 9, 0),
                                child: Text(
                                  "Se connecter",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: "HK Grotesk"),
                                ),
                              ))
                        ],
                      ),
                    ],
                  ),
                  style: OutlinedButton.styleFrom(
                      primary: Colors.white,
                      backgroundColor: lightIconsColor,
                      textStyle: TextStyle(
                        fontSize: 15,
                      ),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5))),
                ),
              ),
            ],
          )),
        ],
      )
    ]);
  }
}
