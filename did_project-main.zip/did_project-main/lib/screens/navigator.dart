import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import '../consts/global_colors.dart';
import 'fichier_page/home_fichier.dart';
import 'fichier_page/liste_fichier.dart';

class Navigateur extends StatefulWidget {
  @override
  State<Navigateur> createState() => _Navigateur();
}

class _Navigateur extends State<Navigateur> {
  int _selectedIndex = 0;
  static const TextStyle optionStyle =
      TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static List<Widget> _widgetOptions = <Widget>[
    Home_fichier(),
    Home_fichier(),
    Home_fichier(),
    Home_fichier(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.business_outlined),
            label: 'Fichier',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business_outlined),
            label: 'Recouvrement',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.money),
            label: 'Paiement',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Mon compte',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: lightIconsColor,
        unselectedItemColor: Colors.black,
        unselectedLabelStyle: TextStyle(color: Colors.black),
        onTap: _onItemTapped,
      ),
    );
  }
}
