import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:recouvre_mobile/widget/liste_cmposant.dart';

import '../../Controlleur/ServiceControlleur.dart';
import '../../consts/global_colors.dart';
import '../../models/Service_Modele.dart';

class Liste_fichier extends StatefulWidget {
  @override
  _Liste_fichier createState() => _Liste_fichier();
}

List<ServiceModel> services = [];

class _Liste_fichier extends State<Liste_fichier> {

@override
void initState() {
  super.initState();
  ServiceController controller = ServiceController();
  controller.getAll().then((list) {
    setState(() {
      services = list;
    });
  });
}
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: ListView.builder(
          itemCount: services.length,
          shrinkWrap: true,
          padding: EdgeInsets.only(top: 2),
          itemBuilder: (context, index) {
            return Liste_composant(
              contenu: "Bonjour",
              name: "le monde",
            );
          },
        ));
  }
}
