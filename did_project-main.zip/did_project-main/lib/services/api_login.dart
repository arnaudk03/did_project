import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
import 'package:recouvre_mobile/consts/api_consts.dart';

import '../models/user_Model.dart';

class  APIHandler{

  static Future<List<dynamic>> getData({required String target,String?limit,}) async{
    try {
      var uri=Uri.https(BASE_URL,"/api/v1/$target",
      );
      var response =await http.get(uri);
      var data=jsonDecode(response.body);
      List tempList=[];
      for (var v in data){
        tempList.add(v);
      }
      return tempList;
    } catch (error) {
      log("An error occurred $error");
      throw error.toString();
    }
  }
static Future<dynamic> getObjectByID({required String target,required String id}) async{
    try {
      var uri=Uri.https(BASE_URL,"/api/v1/$target/$id",);
      var response =await http.get(uri);
      var data=jsonDecode(response.body);
      return data;
    } catch (error) {
      log("An error occurred $error");
      throw error.toString();
    }
  }



  

  
}